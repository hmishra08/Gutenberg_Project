import { Injectable } from '@angular/core';
import {HttpClient } from '@angular/common/http'
import { Observable, of } from 'rxjs';
import { BookList } from './book-list.model';
@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private http: HttpClient) { }

  getBookList(category): Observable<BookList> {
    return this.http.get<BookList>("http://skunkworks.ignitesol.com:8000/books?category="+category+"&&mime_type=image%2Fjpeg");
  }

  getSearchResult(query): Observable<BookList> {
    return this.http.get<BookList>("http://skunkworks.ignitesol.com:8000/books?search="+query+"&&mime_type=image%2Fjpeg");
 
  }

  // downloadFile(filePath: string){
  //   return this.http.get(filePath,{
  //     responseType: 'arraybuffer'
  //   })
  // }
}
