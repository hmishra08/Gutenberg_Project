export class BookList {
    public count: number;
    public next: string;
    public previous: string;
    public results: any[]; 

    constructor(public bookList: BookList ) {
        this.count = bookList && bookList.count || null;
        this.next = bookList && bookList.next || '';
        this.previous = bookList && bookList.previous || '';
        this.results = bookList && bookList.results || null;

    }
    
}