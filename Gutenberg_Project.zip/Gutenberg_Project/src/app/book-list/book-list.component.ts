import { Component, OnInit } from '@angular/core';
import { DataService} from '../data.service';
import { ActivatedRoute, Router } from '@angular/router';
// import { forkJoin } from "rxjs";
// import { saveAs } from "file-saver";
// import * as JSZip from 'jszip';

@Component({
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css']
})
export class BookListComponent implements OnInit {

  searchQuery: string;
  constructor(private dataService: DataService,
              private route: ActivatedRoute,
              private router: Router) { }
  public results: any[];

  ngOnInit() {

    let category = this.route.snapshot.paramMap.get('category');
    console.log(category);

   this.dataService.getBookList(category).subscribe(data=>{
     this.results = data.results;
     this.results.map(data=>{
       data.title = data.title.split(':')[0];
     })
    
   })
  }

  
  bookDetails($event) {
    if($event["text/html; charset=utf-8"]){
      let path = $event["text/html; charset=utf-8"];
      window.open(path);
    } else if($event["application/pdf"]) {
      window.open($event["application/pdf"])
    } else if($event["text/plain"]) {
      window.open($event["text/plain"])
    } else {
      alert("No viewable version available")
    }
  };

  backToHome(){
    this.router.navigate(['/home']);
  }

  search() {
    console.log(this.searchQuery);
    this.dataService.getSearchResult(this.searchQuery).subscribe(data=>{
      this.results = data.results;
    })
  }

  inputSearch(event) {
    if(event.keyCode===13) {
      this.search();
    }
  }

}
